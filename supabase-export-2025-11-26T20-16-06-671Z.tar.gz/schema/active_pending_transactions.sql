CREATE TABLE public.active_pending_transactions (
  
);
