CREATE TABLE public.users (
  "user_id" text,
  "username" text,
  "password" text,
  "first_name" text,
  "last_name" text,
  "contact_number" text,
  "user_email" text,
  "role" text,
  "store_id" text,
  "profile_image" text
);
