CREATE TABLE public.owner_recommendations (
  
);
