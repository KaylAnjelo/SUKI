CREATE TABLE public.notifications (
  "id" text,
  "user_id" text,
  "title" text,
  "message" text,
  "is_read" text,
  "created_at" text
);
