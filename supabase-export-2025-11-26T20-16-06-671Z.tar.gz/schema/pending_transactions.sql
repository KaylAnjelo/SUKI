CREATE TABLE public.pending_transactions (
  "id" text,
  "short_code" text,
  "reference_number" text,
  "transaction_data" text,
  "expires_at" text,
  "used" text,
  "created_at" text
);
