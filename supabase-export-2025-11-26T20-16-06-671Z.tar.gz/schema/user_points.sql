CREATE TABLE public.user_points (
  "id" text,
  "user_id" text,
  "total_points" text,
  "redeemed_points" text,
  "store_id" text
);
