CREATE TABLE public.products (
  "id" text,
  "product_name" text,
  "price" text,
  "store_id" text,
  "product_type" text,
  "product_image" text
);
