CREATE TABLE public.claimed_rewards (
  "id" text,
  "user_id" text,
  "reward_id" text,
  "claimed_at" text,
  "is_redeemed" text
);
