CREATE TABLE public.user_logs (
  "log_id" text,
  "user_id" text,
  "login_time" text,
  "username" text
);
