CREATE TABLE public.stores (
  
);
