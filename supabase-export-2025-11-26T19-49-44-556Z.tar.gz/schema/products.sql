CREATE TABLE public.products (
  
);
